﻿namespace kalkulator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button0 = new Button();
            btnPlus = new Button();
            btnMinus = new Button();
            btnMul = new Button();
            btnDiv = new Button();
            button15 = new Button();
            display = new TextBox();
            btnEquals = new Button();
            button10 = new Button();
            btnNeg = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Lavender;
            button1.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(12, 207);
            button1.Name = "button1";
            button1.Size = new Size(51, 51);
            button1.TabIndex = 0;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Lavender;
            button2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(69, 207);
            button2.Name = "button2";
            button2.Size = new Size(51, 51);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Lavender;
            button3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button3.Location = new Point(126, 207);
            button3.Name = "button3";
            button3.Size = new Size(51, 51);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Lavender;
            button4.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button4.Location = new Point(12, 150);
            button4.Name = "button4";
            button4.Size = new Size(51, 51);
            button4.TabIndex = 3;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button1_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Lavender;
            button5.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button5.Location = new Point(69, 150);
            button5.Name = "button5";
            button5.Size = new Size(51, 51);
            button5.TabIndex = 4;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button1_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.Lavender;
            button6.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button6.Location = new Point(126, 150);
            button6.Name = "button6";
            button6.Size = new Size(51, 51);
            button6.TabIndex = 5;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button1_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.Lavender;
            button7.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button7.Location = new Point(12, 93);
            button7.Name = "button7";
            button7.Size = new Size(51, 51);
            button7.TabIndex = 6;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button1_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.Lavender;
            button8.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button8.Location = new Point(69, 93);
            button8.Name = "button8";
            button8.Size = new Size(51, 51);
            button8.TabIndex = 7;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button1_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.Lavender;
            button9.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button9.Location = new Point(126, 93);
            button9.Name = "button9";
            button9.Size = new Size(51, 51);
            button9.TabIndex = 8;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button1_Click;
            // 
            // button0
            // 
            button0.BackColor = Color.Lavender;
            button0.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button0.Location = new Point(69, 264);
            button0.Name = "button0";
            button0.Size = new Size(51, 51);
            button0.TabIndex = 9;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = false;
            button0.Click += button1_Click;
            // 
            // btnPlus
            // 
            btnPlus.BackColor = Color.LemonChiffon;
            btnPlus.Font = new Font("Segoe UI Symbol", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnPlus.Location = new Point(188, 93);
            btnPlus.Name = "btnPlus";
            btnPlus.Size = new Size(51, 51);
            btnPlus.TabIndex = 10;
            btnPlus.Text = "+";
            btnPlus.UseVisualStyleBackColor = false;
            btnPlus.Click += btnCalc_Click;
            // 
            // btnMinus
            // 
            btnMinus.BackColor = Color.LemonChiffon;
            btnMinus.Font = new Font("Segoe UI Symbol", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnMinus.Location = new Point(188, 150);
            btnMinus.Name = "btnMinus";
            btnMinus.Size = new Size(51, 51);
            btnMinus.TabIndex = 11;
            btnMinus.Text = "-";
            btnMinus.UseVisualStyleBackColor = false;
            btnMinus.Click += btnCalc_Click;
            // 
            // btnMul
            // 
            btnMul.BackColor = Color.LemonChiffon;
            btnMul.Font = new Font("Segoe UI Symbol", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnMul.Location = new Point(188, 207);
            btnMul.Name = "btnMul";
            btnMul.Size = new Size(51, 51);
            btnMul.TabIndex = 12;
            btnMul.Text = "*";
            btnMul.UseVisualStyleBackColor = false;
            btnMul.Click += btnCalc_Click;
            // 
            // btnDiv
            // 
            btnDiv.BackColor = Color.LemonChiffon;
            btnDiv.Font = new Font("Segoe UI Symbol", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnDiv.Location = new Point(188, 262);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(51, 51);
            btnDiv.TabIndex = 13;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = false;
            btnDiv.Click += btnCalc_Click;
            // 
            // button15
            // 
            button15.BackColor = Color.Thistle;
            button15.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            button15.Location = new Point(188, 321);
            button15.Name = "button15";
            button15.Size = new Size(51, 48);
            button15.TabIndex = 14;
            button15.Text = "C";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // display
            // 
            display.Font = new Font("Agency FB", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            display.Location = new Point(12, 23);
            display.Multiline = true;
            display.Name = "display";
            display.Size = new Size(227, 50);
            display.TabIndex = 15;
            // 
            // btnEquals
            // 
            btnEquals.BackColor = Color.Khaki;
            btnEquals.Font = new Font("Segoe UI Symbol", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnEquals.Location = new Point(12, 321);
            btnEquals.Name = "btnEquals";
            btnEquals.Size = new Size(165, 48);
            btnEquals.TabIndex = 16;
            btnEquals.Text = "=";
            btnEquals.UseVisualStyleBackColor = false;
            btnEquals.Click += btnEquals_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.Lavender;
            button10.Font = new Font("Segoe UI Symbol", 18F, FontStyle.Bold, GraphicsUnit.Point);
            button10.Location = new Point(12, 264);
            button10.Name = "button10";
            button10.Size = new Size(51, 51);
            button10.TabIndex = 17;
            button10.Text = ",";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button1_Click;
            // 
            // btnNeg
            // 
            btnNeg.BackColor = Color.LavenderBlush;
            btnNeg.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnNeg.Location = new Point(126, 264);
            btnNeg.Name = "btnNeg";
            btnNeg.Size = new Size(51, 51);
            btnNeg.TabIndex = 18;
            btnNeg.Text = "+/-";
            btnNeg.UseVisualStyleBackColor = false;
            btnNeg.Click += btnNeg_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(251, 381);
            Controls.Add(btnNeg);
            Controls.Add(button10);
            Controls.Add(btnEquals);
            Controls.Add(display);
            Controls.Add(button15);
            Controls.Add(btnDiv);
            Controls.Add(btnMul);
            Controls.Add(btnMinus);
            Controls.Add(btnPlus);
            Controls.Add(button0);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private TextBox display;
        private Button button16;
        private Button btnEquals;
        private Button btnCalc;
        private Button button0;
        private Button btnPlus;
        private Button btnMinus;
        private Button btnMul;
        private Button btnDiv;
        private Button btnNeg;
    }
}